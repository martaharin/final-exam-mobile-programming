<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

include 'database.php';
$email = $_GET['email'] ?? '';
$password = $_GET['password'] ?? '';
$pin = $_GET['pin'] ?? '';

// Query the database
$sql = "SELECT id, name, email, pin, password FROM customers WHERE email = '$email' AND password = '$password' AND pin = '$pin'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $data = $result->fetch_assoc();
    echo json_encode(['success' => true, 'customer' => $data]);
} else {
    echo json_encode(['success' => false, 'message' => 'Customer not found']);
}

$conn->close();
?>
