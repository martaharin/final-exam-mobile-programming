<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

include 'database.php';

$response = [];

// Validate input
if (!isset($_POST['name']) || !isset($_POST['email']) || !isset($_POST['pin']) || !isset($_POST['password'])) {
    http_response_code(400);
    $response['error'] = "Missing required fields";
    echo json_encode($response);
    exit;
}

$name = $_POST['name'];
$email = $_POST['email'];
$pin = $_POST['pin'];
$password = $_POST['password'];

// Insert into database
$sql = "INSERT INTO customers (name, email, pin, password) VALUES (?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssis", $name, $email, $pin, $password);

if ($stmt->execute()) {
    $response['success'] = true;
    $response['id'] = $stmt->insert_id; // Return the inserted customer ID
    $response['message'] = "Customer created successfully";
} else {
    http_response_code(500);
    $response['success'] = false;
    $response['error'] = "Error: " . $stmt->error;
}

echo json_encode($response);

$stmt->close();
$conn->close();
?>
