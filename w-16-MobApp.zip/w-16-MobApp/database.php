<?php
// Database configuration
$servername = "localhost";
$username = "root";
$password = ""; // Change this to your database password
$dbname = "w_16_mobapp"; // Replace with your database name

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
